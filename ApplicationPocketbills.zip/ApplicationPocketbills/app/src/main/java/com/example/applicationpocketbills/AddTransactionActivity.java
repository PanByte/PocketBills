package com.example.applicationpocketbills;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.applicationpocketbills.databinding.ActivityAddTransactionBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AddTransactionActivity extends AppCompatActivity {
 ActivityAddTransactionBinding binding;
 FirebaseFirestore fstore;
 FirebaseAuth firebaseAuth;
 FirebaseUser firebaseUser;
 String type="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddTransactionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        fstore=FirebaseFirestore.getInstance();
        firebaseAuth=FirebaseAuth.getInstance();
        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

        binding.expenseBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type="Expense";
                binding.expenseBox.setChecked(true);
                binding.incomeBox.setChecked(false);
            }
        });
        binding.incomeBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type="Income";
                binding.expenseBox.setChecked(false);
                binding.incomeBox.setChecked(true);
            }
        });
        binding.btnAddTransact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String amtAdd = binding.userAmtAdd.getText().toString().trim();
                String note = binding.userNote.getText().toString().trim();
                if (amtAdd.length() <= 0) {
                    return;
                }
                Map<String, Object> transaction = null;
                if (type.length()<=0) {
                    Toast.makeText(AddTransactionActivity.this,"Select transaction type",Toast.LENGTH_SHORT).show();
                }
                transaction = new HashMap<>();
                String id = null;
                transaction.put("id", id);
                transaction.put("amount", amtAdd);
                transaction.put("note", note);
                transaction.put("type", type);

                id = UUID.randomUUID().toString();
                fstore.collection("Expenses").document(firebaseAuth.getUid()).collection("Notes").document(id)
                        .set(transaction)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(AddTransactionActivity.this, "Added", Toast.LENGTH_SHORT).show();
                                binding.userNote.setText("");
                                binding.userAmtAdd.setText("");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(AddTransactionActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });



    }
}